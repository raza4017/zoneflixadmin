export default function toDataURL(url: string): Promise<string>;
