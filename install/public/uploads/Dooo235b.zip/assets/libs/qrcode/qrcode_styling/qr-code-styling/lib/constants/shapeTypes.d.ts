import { ShapeTypes } from "../types";
declare const _default: ShapeTypes;
export default _default;
