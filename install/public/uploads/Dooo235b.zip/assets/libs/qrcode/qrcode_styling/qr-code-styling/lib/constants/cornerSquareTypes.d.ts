import { CornerSquareTypes } from "../types";
declare const _default: CornerSquareTypes;
export default _default;
