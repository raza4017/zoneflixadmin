import { RequiredOptions } from "../core/QROptions";
export default function sanitizeOptions(options: RequiredOptions): RequiredOptions;
