import { DrawTypes } from "../types";
declare const _default: DrawTypes;
export default _default;
