import { GradientTypes } from "../types";
declare const _default: GradientTypes;
export default _default;
