import { TypeNumber } from "../types";
interface TypesMap {
    [key: number]: TypeNumber;
}
declare const qrTypes: TypesMap;
export default qrTypes;
