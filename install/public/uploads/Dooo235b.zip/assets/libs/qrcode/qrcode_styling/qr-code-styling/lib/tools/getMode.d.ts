import { Mode } from "../types";
export default function getMode(data: string): Mode;
