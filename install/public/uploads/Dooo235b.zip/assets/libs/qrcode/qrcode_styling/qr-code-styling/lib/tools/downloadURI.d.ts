export default function downloadURI(uri: string, name: string): void;
