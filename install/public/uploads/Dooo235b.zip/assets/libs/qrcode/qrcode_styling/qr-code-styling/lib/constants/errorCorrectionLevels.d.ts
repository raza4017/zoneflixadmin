import { ErrorCorrectionLevel } from "../types";
interface ErrorCorrectionLevels {
    [key: string]: ErrorCorrectionLevel;
}
declare const _default: ErrorCorrectionLevels;
export default _default;
