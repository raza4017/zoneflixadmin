import { CornerDotTypes } from "../types";
declare const _default: CornerDotTypes;
export default _default;
