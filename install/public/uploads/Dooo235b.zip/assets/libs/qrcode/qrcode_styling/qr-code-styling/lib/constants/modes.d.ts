import { Mode } from "../types";
interface Modes {
    [key: string]: Mode;
}
declare const _default: Modes;
export default _default;
