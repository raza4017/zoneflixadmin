import { UnknownObject } from "../types";
export default function mergeDeep(target: UnknownObject, ...sources: UnknownObject[]): UnknownObject;
