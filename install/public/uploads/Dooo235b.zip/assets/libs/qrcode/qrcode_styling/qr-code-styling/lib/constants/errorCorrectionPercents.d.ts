interface ErrorCorrectionPercents {
    [key: string]: number;
}
declare const _default: ErrorCorrectionPercents;
export default _default;
