import { DotTypes } from "../types";
declare const _default: DotTypes;
export default _default;
