<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Login
$lang['welcome_back']		= 'Добро пожаловать !';
$lang['sign_in_to_continue_to_dooo']		= 'Войдите, чтобы продолжить Dooo.';
$lang['remember_me']		= 'Запомни меня';
$lang['log_in']		= 'Авторизоваться';
$lang['forgot_your_password']		= 'Забыли Ваш пароль?';