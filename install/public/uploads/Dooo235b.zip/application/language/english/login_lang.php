<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Login
$lang['welcome_back']		= 'Welcome Back !';
$lang['sign_in_to_continue_to_dooo']		= 'Sign in to continue to Dooo.';
$lang['remember_me']		= 'Remember me';
$lang['log_in']		= 'Log In';
$lang['forgot_your_password']		= 'Forgot your password?';