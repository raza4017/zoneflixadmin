<meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Dooo - Movie & Web Series Portal App" name="description">
        <meta content="Team-Dooo" name="author">
        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo base_url('assets/images/favicon.ico') ?>">
    
        <link href="<?php echo base_url('assets/libs/chartist/chartist.min.css" rel="stylesheet') ?>">

        <link href="<?php echo base_url('assets/css/scrollbar.css') ?>" rel="stylesheet">

        <!-- Toaster-->
        <link href="<?php echo base_url('assets/libs/toaster/toastr.min.css') ?>" rel="stylesheet" type="text/css" />

        <!-- Sweet Alert-->
        <link href="<?php echo base_url('assets/libs/sweetalert2/sweetalert2.min.css') ?>" rel="stylesheet" type="text/css" />

        <!-- Summernote css -->
        <link href="<?php echo base_url('assets/libs/summernote/summernote.css') ?>" rel="stylesheet" type="text/css" />

        <!-- Dropzone css -->
        <link href="<?php echo base_url('assets/libs/dropzone/min/dropzone.min.css') ?>" rel="stylesheet" type="text/css">

        <!-- DataTables -->
        <link href="<?php echo base_url('assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css') ?>" rel="stylesheet" type="text/css" />

        <link href="<?php echo base_url('assets/libs/select2/css/select2.min.css') ?>" rel="stylesheet" type="text/css">
        
        <link href="<?php echo base_url('assets/libs/bootstrap-datepicker/css/bootstrap-datepicker.min.css') ?>" rel="stylesheet">

        <link href="<?php echo base_url('assets/libs/spectrum-colorpicker2/spectrum.min.css') ?>" rel="stylesheet">

        <!-- Bootstrap Css -->
        <link href="<?php echo base_url('assets/css/bootstrap-dark.min.css') ?>" id="bootstrap-style" rel="stylesheet" type="text/css">
        <!-- Icons Css -->
        <link href="<?php echo base_url('assets/css/icons.min.css') ?>" rel="stylesheet" type="text/css">
        <!-- App Css-->
        <link href="<?php echo base_url('assets/css/app-dark.min.css') ?>" id="app-style" rel="stylesheet" type="text/css">