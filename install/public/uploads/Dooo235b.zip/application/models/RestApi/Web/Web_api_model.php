<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Web_api_model extends CI_Model {
	function __construct()
	{
		parent::__construct();
	}
    
}